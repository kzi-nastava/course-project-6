using System;
using ProjectUSI.Manager.Model;
using ProjectUSI.Manager.Repository;
using ProjectUSI.Manager.View;

namespace ProjectUSI.Manager.Controller
{
    public class EquipmentController
    {
        private Equipment _model;
        private EquipmentRepository _equipmentRepository;
        private EquipmentWindow _view;

        public EquipmentController(Equipment model, EquipmentWindow view, EquipmentRepository roomRepository)
        {
            this._model = model;
            this._equipmentRepository = roomRepository;
            this._view = view;
        }
        private void ResetForm()
        {
            _view.Dispose();
            EquipmentWindow equipmentWindow = new EquipmentWindow(_equipmentRepository, new EquipmentController(_model, null, _equipmentRepository));
            equipmentWindow.Show();
        }

        public void DeletEquipment(int index)
        {
            Equipment equipment = _equipmentRepository.GetEquipment()[index];
            if (equipment != null)
            {
                _equipmentRepository.DeleteEquipment(equipment);
                this.ResetForm();
            }
            else
            {
                throw new NullReferenceException();
            }
        }

        public void UpdateEquipment(int index)
        {
            Equipment equipment = _equipmentRepository.GetEquipment()[index];
            if (equipment != null)
            {
                _equipmentRepository.DeleteEquipment(equipment);
                AddEquipmentWindow addEquipmentWindow = new AddEquipmentWindow(_equipmentRepository, equipment);
                addEquipmentWindow.Show();
            }
            else
            {
                throw new NullReferenceException();
            }
            
        }


    }
}
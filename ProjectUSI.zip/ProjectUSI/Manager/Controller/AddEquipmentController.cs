using ProjectUSI.Manager.Model;
using ProjectUSI.Manager.Repository;
using ProjectUSI.Manager.View;

namespace ProjectUSI.Manager.Controller
{
    public class AddEquipmentController
    {
        private EquipmentRepository _equipmentRepository;
        private AddEquipmentWindow _view;
        private RoomRepository _roomRepository = new RoomRepository();
        private Equipment _model;

        public AddEquipmentController(Equipment model, AddEquipmentWindow view, EquipmentRepository equipmentRepository)
        {
            this._equipmentRepository = equipmentRepository;
            this._view = view;
            this._model = model;
        }
        

        public void Submit(string name, string id, string roomId, EquipmentType equipmentType)
        {
            Equipment equipment = new Equipment()
            {
                Id = id, 
                Name = name,
                DeployedIn = _roomRepository.GetRoomById(roomId),
                EquipmentType = equipmentType
            };
            _equipmentRepository.InsertEquipment(equipment);
            _view.Dispose();
            EquipmentWindow equipmentWindow = new EquipmentWindow(_equipmentRepository, new EquipmentController(_model, null, _equipmentRepository));
            equipmentWindow.Show();
        }
    }
}
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using ProjectUSI.Manager.Model;

namespace ProjectUSI.Manager.Repository
{
    public class EquipmentRepository
    {
        private List<Equipment> _equipment;

        public EquipmentRepository()
        {
            string json = File.ReadAllText(@"C:\Users\ANJA\course-project-6\ProjectUSI\Data\Equipment.json");
            List<Equipment> equipment = JsonConvert.DeserializeObject<List<Equipment>>(json);
            _equipment = equipment;
        }
        public List<Equipment> GetEquipment()
        {
            return this._equipment;
        }

        public Equipment GetEquipmentById(string id)
        {
            foreach (Equipment equipment in _equipment)
            {
                if (equipment.Id.Equals(id))
                {
                    return equipment;
                }
            }
            return null;
        }

        public void InsertEquipment(Equipment equipment)
        {
            _equipment.Add(equipment);
        }

        public void DeleteEquipment(Equipment equipment)
        {
            _equipment.Remove(equipment);
        }

        public void UpdateEquipment(Equipment equipment)
        {
            Equipment pieceOfEquipmentForUpdate = GetEquipmentById(equipment.Id);
            _equipment.Remove(pieceOfEquipmentForUpdate);
            pieceOfEquipmentForUpdate.Name = equipment.Name;
            pieceOfEquipmentForUpdate.DeployedIn = equipment.DeployedIn;
            pieceOfEquipmentForUpdate.EquipmentType = equipment.EquipmentType;
            _equipment.Add(pieceOfEquipmentForUpdate);
        }
        
        public void Save()
        {
            File.WriteAllText(@"C:\Users\ANJA\course-project-6\ProjectUSI\Data\Equipment.json", JsonConvert.SerializeObject(_equipment));
        }
    }
}
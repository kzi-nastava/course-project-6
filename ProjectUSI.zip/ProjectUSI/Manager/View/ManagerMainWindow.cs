using System;
using System.Windows.Forms;

namespace ProjectUSI.Manager.View
{
    public partial class ManagerMainWindow : Form
    {
        public ManagerMainWindow()
        {
            InitializeComponent();
            //pnlMainLbl.Text = pnlMainLbl.Text + String.Concat("\n anja123");
            //ToDo: dodati email ime i prezime menadzera koji se ulogovao;
        }
        

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            /*LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Dispose(false);*/
        }

        private void btnEquipmentRewiev_Click(object sender, EventArgs e)
        {
            /*EquipmentManager equipmentManager = new EquipmentManager();
            EquipmentWindow equipmentWindow = new EquipmentWindow(equipmentManager);
            equipmentWindow.Show();*/
        }

        private void btnRooms_Click(object sender, EventArgs e)
        {
            /*RoomsManager roomsManager = new RoomsManager();
            RoomsWindow roomsWindow = new RoomsWindow(roomsManager);
            roomsWindow.Show();*/
        }
    }
}
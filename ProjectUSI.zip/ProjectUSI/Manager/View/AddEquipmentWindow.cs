using System;
using System.Windows.Forms;
using ProjectUSI.Manager.Controller;
using ProjectUSI.Manager.Model;
using ProjectUSI.Manager.Repository;

namespace ProjectUSI.Manager.View
{
    public partial class AddEquipmentWindow : Form
    {
        public AddEquipmentController _controller;
        private EquipmentRepository _equipmentRepository;
        public AddEquipmentWindow(EquipmentRepository equipmentRepository, Equipment equipment)
        {
            _equipmentRepository = equipmentRepository;
            _controller = new AddEquipmentController(equipment, this, _equipmentRepository);
            InitializeComponent();
            SetDefaultParams(equipment);
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string id = txtBoxId.Text;
            string name = txtBoxName.Text;
            string roomId = txtBoxDeployedIn.Text;
            EquipmentType firstChecked = EquipmentType.HallEquipment;
            _controller.Submit(name, id, roomId, firstChecked);
        }
        
        private void SetDefaultParams(Equipment equipment)
        {
            if (equipment != null)
            {
                txtBoxName.Text = equipment.Name;
                txtBoxId.Text = equipment.Id;
                txtBoxDeployedIn.Text = equipment.DeployedIn.Id;
                try
                {
                    Int32 typeIndex = (Int32) equipment.EquipmentType;
                    cbEquipmentType.SetSelected(typeIndex, true);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }
        }
    }
}
using System.ComponentModel;

namespace ProjectUSI.Manager.View
{
    partial class AddEquipmentWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblId = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblDeployedIn = new System.Windows.Forms.Label();
            this.lblEquipmentType = new System.Windows.Forms.Label();
            this.txtBoxId = new System.Windows.Forms.TextBox();
            this.txtBoxName = new System.Windows.Forms.TextBox();
            this.txtBoxDeployedIn = new System.Windows.Forms.TextBox();
            this.cbEquipmentType = new System.Windows.Forms.CheckedListBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblId
            // 
            this.lblId.Font = new System.Drawing.Font("Orbitron", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblId.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblId.Location = new System.Drawing.Point(29, 58);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(151, 31);
            this.lblId.TabIndex = 1;
            this.lblId.Text = "ID:";
            // 
            // lblName
            // 
            this.lblName.Font = new System.Drawing.Font("Orbitron", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblName.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblName.Location = new System.Drawing.Point(29, 123);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(151, 31);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "NAME:";
            // 
            // lblDeployedIn
            // 
            this.lblDeployedIn.Font = new System.Drawing.Font("Orbitron", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblDeployedIn.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblDeployedIn.Location = new System.Drawing.Point(29, 190);
            this.lblDeployedIn.Name = "lblDeployedIn";
            this.lblDeployedIn.Size = new System.Drawing.Size(151, 45);
            this.lblDeployedIn.TabIndex = 3;
            this.lblDeployedIn.Text = "DEPLOYED IN:\r\n(ID OF ROOM)";
            // 
            // lblEquipmentType
            // 
            this.lblEquipmentType.Font = new System.Drawing.Font("Orbitron", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblEquipmentType.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.lblEquipmentType.Location = new System.Drawing.Point(29, 270);
            this.lblEquipmentType.Name = "lblEquipmentType";
            this.lblEquipmentType.Size = new System.Drawing.Size(202, 31);
            this.lblEquipmentType.TabIndex = 4;
            this.lblEquipmentType.Text = "EQUIPMENT TYPE:";
            // 
            // txtBoxId
            // 
            this.txtBoxId.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtBoxId.Location = new System.Drawing.Point(275, 50);
            this.txtBoxId.Multiline = true;
            this.txtBoxId.Name = "txtBoxId";
            this.txtBoxId.Size = new System.Drawing.Size(186, 39);
            this.txtBoxId.TabIndex = 5;
            // 
            // txtBoxName
            // 
            this.txtBoxName.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtBoxName.Location = new System.Drawing.Point(275, 115);
            this.txtBoxName.Multiline = true;
            this.txtBoxName.Name = "txtBoxName";
            this.txtBoxName.Size = new System.Drawing.Size(186, 39);
            this.txtBoxName.TabIndex = 6;
            // 
            // txtBoxDeployedIn
            // 
            this.txtBoxDeployedIn.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtBoxDeployedIn.Location = new System.Drawing.Point(275, 190);
            this.txtBoxDeployedIn.Multiline = true;
            this.txtBoxDeployedIn.Name = "txtBoxDeployedIn";
            this.txtBoxDeployedIn.Size = new System.Drawing.Size(186, 39);
            this.txtBoxDeployedIn.TabIndex = 7;
            // 
            // cbEquipmentType
            // 
            this.cbEquipmentType.FormattingEnabled = true;
            this.cbEquipmentType.Items.AddRange(new object[] {"RewievEquipment", "OperationEquipment", "RoomFurniture", "HallEquipment"});
            this.cbEquipmentType.Location = new System.Drawing.Point(275, 255);
            this.cbEquipmentType.Name = "cbEquipmentType";
            this.cbEquipmentType.Size = new System.Drawing.Size(186, 72);
            this.cbEquipmentType.TabIndex = 8;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnSubmit.Font = new System.Drawing.Font("Orbitron", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnSubmit.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.btnSubmit.Location = new System.Drawing.Point(275, 358);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(186, 45);
            this.btnSubmit.TabIndex = 10;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // AddEquipmentWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 450);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.cbEquipmentType);
            this.Controls.Add(this.txtBoxDeployedIn);
            this.Controls.Add(this.txtBoxName);
            this.Controls.Add(this.txtBoxId);
            this.Controls.Add(this.lblEquipmentType);
            this.Controls.Add(this.lblDeployedIn);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblId);
            this.Name = "AddEquipmentWindow";
            this.Text = "AddEquipmentWindow";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btnSubmit;

        private System.Windows.Forms.CheckedListBox cbEquipmentType;

        private System.Windows.Forms.TextBox txtBoxId;
        private System.Windows.Forms.TextBox txtBoxName;
        private System.Windows.Forms.TextBox txtBoxDeployedIn;

        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblDeployedIn;
        private System.Windows.Forms.Label lblEquipmentType;

        #endregion
    }
}
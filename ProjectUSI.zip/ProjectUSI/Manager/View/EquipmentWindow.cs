using System;
using System.Linq;
using System.Windows.Forms;
using ProjectUSI.Manager.Controller;
using ProjectUSI.Manager.Model;
using ProjectUSI.Manager.Repository;

namespace ProjectUSI.Manager.View
{
    public partial class EquipmentWindow : Form
    {
        private EquipmentRepository _equipmentRepository;
        public EquipmentController _controller;
        public EquipmentWindow(EquipmentRepository equipmentRepository, EquipmentController equipmentController)
        {
            _equipmentRepository = equipmentRepository;
            _controller = equipmentController;
            
            InitializeComponent();
            for (int i = 0; i < _equipmentRepository.GetEquipment().Count; i++)
            {
                listBox1.Items.Add(_equipmentRepository.GetEquipment().ElementAt(i).ToString());
            }
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            this.Dispose(false);
            AddEquipmentWindow addEquipmentWindow = new AddEquipmentWindow(_equipmentRepository, null);
            addEquipmentWindow.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBox1.SelectedIndex;
                this.Dispose(false);
                _controller.UpdateEquipment(index);
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Room does not exist!");
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("You need to select room!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBox1.SelectedIndex;
                _controller.DeletEquipment(index);

            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Room does not exist!");
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("You need to select room!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
            
        }

        private void btnDeploy_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
        
        private void RoomsWindow_Load(object sender, EventArgs e)
        {
            _equipmentRepository.Save();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string myString = textBox1.Text;
            bool found = false;
            for (int i = 0; i <= listBox1.Items.Count - 1; i++)
            {
                if(listBox1.Items[i].ToString().Contains(myString))
                {
                    listBox1.SetSelected(i, true);
                    found = true;
                    break;
                }
            }                        
            if(!found)
            {
                MessageBox.Show("Item not found!");
            }                
        }

        
    }
    
    
}
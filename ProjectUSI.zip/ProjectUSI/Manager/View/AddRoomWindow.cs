using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ProjectUSI.Manager.Controller;
using ProjectUSI.Manager.Model;
using ProjectUSI.Manager.Repository;

namespace ProjectUSI.Manager.View
{
    public partial class AddRoomWindow : Form
    {
        private RoomRepository _roomRepository;
        public AddRoomController _controller;
        public AddRoomWindow(RoomRepository roomRepository, Room room)
        {
            _roomRepository = roomRepository;
            _controller = new AddRoomController(room, this, _roomRepository);
            InitializeComponent();
            SetDefaultParams(room);
            
        }


        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string name = txtBoxNameOfRoom.Text;
                string id = txtBoxIdOfRoom.Text;
                RoomPurpose firstChecked = (RoomPurpose)cbPurpose.CheckedItems[0];
                int area = Int32.Parse(txtBoxArea.Text);
                _controller.Submit(name, id, firstChecked, area);
            }
            catch (FormatException)
            {
                MessageBox.Show("Wrong area input, area must be number!");
            }
            
        }

        private void SetDefaultParams(Room room)
        {
            if (room != null)
            {
                txtBoxNameOfRoom.Text = room.Name;
                txtBoxIdOfRoom.Text = room.Id;
                txtBoxArea.Text = room.Area.ToString();
                try
                {
                    Int32 PurposeIndex = (Int32) room.Purpose;
                    cbPurpose.SetSelected(PurposeIndex, true);
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }
        }

    }
}
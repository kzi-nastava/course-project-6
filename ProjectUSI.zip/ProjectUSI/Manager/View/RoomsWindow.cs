using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ProjectUSI.Manager.Model;
using ProjectUSI.Manager.Controller;
using ProjectUSI.Manager.Repository;

namespace ProjectUSI.Manager.View
{
    public partial class RoomsWindow : Form
    {
        private RoomRepository _roomRepository;
        private List<Room> _rooms;
        public RoomController _controller;
        public RoomsWindow(RoomRepository roomRepository, RoomController roomController)
        {
            _roomRepository = roomRepository;
            _rooms = _roomRepository.GetRooms();
            _controller = roomController;
            
            InitializeComponent();
            
            for (int i = 0; i < _rooms.Count; i++)
            {
                listBox1.Items.Add(_rooms.ElementAt(i).ToString());
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            this.Dispose(false);
            AddRoomWindow addRoomWindow = new AddRoomWindow(_roomRepository, null);
            addRoomWindow.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBox1.SelectedIndex;
                this.Dispose(false);
                _controller.UpdateRoom(index);
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Room does not exist!");
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("You need to select room!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBox1.SelectedIndex;
                _controller.DeleteRoom(index);

            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Room does not exist!");
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("You need to select room!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
            
        }


        private void RoomsWindow_Load(object sender, EventArgs e)
        {
            _roomRepository.Save();
        }
    }
    
    
}
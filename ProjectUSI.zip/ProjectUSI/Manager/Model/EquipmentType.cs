namespace ProjectUSI.Manager.Model
{
    public enum EquipmentType
    {
        RewievEquipment,
        OperationEquipment,
        RoomFurniture,
        HallEquipment
    }
}
namespace ProjectUSI.Manager.Model
{
    public enum RoomPurpose
    {
        OperationRoom,
        ExaminationRoom,
        RestRoom,
        PatientRoom,
        Cafeteria,
        ManagementRoom
    }
}
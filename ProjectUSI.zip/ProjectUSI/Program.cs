﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProjectUSI.Manager.Controller;
using ProjectUSI.Manager.Model;
using ProjectUSI.Manager.Repository;
using ProjectUSI.Manager.View;

namespace ProjectUSI
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            RoomRepository roomRepository = new RoomRepository();
            RoomsWindow roomsWindow = new RoomsWindow(roomRepository, null);
            RoomController roomController = new RoomController(new Room(), roomsWindow, roomRepository);
            roomsWindow._controller = roomController;
            EquipmentRepository equipmentRepository = new EquipmentRepository();
            EquipmentWindow equipmentWindow = new EquipmentWindow(equipmentRepository, null);
            EquipmentController equipmentController = new EquipmentController(new Equipment(), equipmentWindow, equipmentRepository);
            equipmentWindow._controller = equipmentController;
            Application.Run(equipmentWindow);
        }
    }
}